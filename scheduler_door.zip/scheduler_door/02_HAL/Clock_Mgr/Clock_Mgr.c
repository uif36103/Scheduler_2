// Clock manager module
//
// Clock tree configuration. By now the clock is in its default value (20 MHz).

#include "Clock_Mgr.h"

// TODO Config clk
// Empty
