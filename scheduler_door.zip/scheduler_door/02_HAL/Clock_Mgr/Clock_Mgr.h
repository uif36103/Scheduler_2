// Clock manager module
//
// Clock manager prototypes or definitions. By now the clock is in its default value (20 MHz).

#ifndef CLOCK_MGR_CLOCK_MGR_H_
#define CLOCK_MGR_CLOCK_MGR_H_

// TODO Config clk
// Empty

#endif
